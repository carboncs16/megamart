package com.megamart.login.model;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

public class RegisterUser {
	@NotEmpty(message = "UserId must not be blank.")
	@Size(min = 4, max = 15, message = "UserId must be between 4 to 15 Characters.")
	private String username;
	
	@NotEmpty(message = "Password must not be blank.")
    @Size(min = 8, max = 15, message = "Password must be between 8 to 15 Characters.")
	private String password;
	
	@NotEmpty(message = "Email must be blank")
	@Email(message = "Enter correct Email-Id")
	private String email;
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
