package com.megamart.login.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.transaction.annotation.Transactional;

import com.megamart.login.document.CredentialsDocument;
import com.megamart.login.model.User;

@Transactional
public interface UserRepository extends MongoRepository<CredentialsDocument, String> {
	public CredentialsDocument findByUsername(String username);
}
