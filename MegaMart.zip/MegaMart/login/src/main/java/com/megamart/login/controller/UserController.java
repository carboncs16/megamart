package com.megamart.login.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import com.megamart.login.model.RegisterUser;
import com.megamart.login.model.User;
import com.megamart.login.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	UserService userService;
	
	@RequestMapping(value = "/login", method = RequestMethod.POST, headers="Accept=application/json")
	public ResponseEntity<String> login(@RequestBody User user) {
		String status = userService.loginUser(user);
		return new ResponseEntity<String>(status, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/register", method = RequestMethod.POST, headers="Accept=application/json")
	public ResponseEntity<String> login(@RequestBody RegisterUser user) {
		String status = userService.registerUser(user);
		return new ResponseEntity<String>(status, HttpStatus.OK);
	}
}
