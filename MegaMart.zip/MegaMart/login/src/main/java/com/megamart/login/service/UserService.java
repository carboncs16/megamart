package com.megamart.login.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.megamart.login.document.CredentialsDocument;
import com.megamart.login.model.RegisterUser;
import com.megamart.login.model.User;
import com.megamart.login.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	public String loginUser(User user) {
		CredentialsDocument cd = userRepository.findByUsername(user.getUsername());
		if (cd == null)
			return "Username doesn't exist";
		if (cd.getPassword().equals(user.getPassword())) {
			return "Login Successful";
		} else {
			return "Invalid Credentials";
		}
	}
	
	public String registerUser(RegisterUser user) {
		CredentialsDocument cd1 = userRepository.findByUsername(user.getUsername());
		if (cd1 != null)
			return "User Already Exists";
		
		CredentialsDocument cd = new CredentialsDocument();
		cd .setEmail(user.getEmail());
		cd.setUsername(user.getUsername());
		cd.setPassword(user.getPassword());
		userRepository.insert(cd);
		return "Registration Successful";
	}

}
