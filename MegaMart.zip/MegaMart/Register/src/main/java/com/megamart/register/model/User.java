package com.megamart.register.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

public class User {
	
	@NotEmpty(message = "UserId must not be blank.")
	@Size(min = 4, max = 15, message = "UserId must be between 4 to 15 Characters.")
	private String username;
	
	@NotEmpty(message = "Password must not be blank.")
	@Size(min = 4, max = 15, message = "UserId must be between 4 to 15 Characters.")
	private String password;
	
	@NotEmpty(message = "Email must not be blank.")
	private String email;
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
