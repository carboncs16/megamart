package com.megamart.product.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.megamart.product.document.ProductDocument;
import com.megamart.product.model.Product;
import com.megamart.product.repository.ProductRepository;


@Service
public class ProductService {
	
	@Autowired
	ProductRepository pr;

	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		List<ProductDocument> productArr = pr.findAll();
		List<Product> prodArr = new ArrayList<Product>();
		
		for (ProductDocument product : productArr) {
			Product p = new Product();
			p.setDelivery(product.getDelivery());
			p.setDiscount(product.getDiscount());
			p.setpDesc(product.getpDesc());
			p.setpName(product.getpName());
			p.setPrice(product.getPrice());
			p.setProductId(product.getProductId());
			p.setRating(product.getRating());
			p.setSeller(product.getSeller());
			prodArr.add(p);
		}
		return prodArr;
	}

	public Product getProductById(String productId) {
		// TODO Auto-generated method stub
		Optional<ProductDocument> fetchDetails = pr.findById(productId);
		ProductDocument pd = fetchDetails.get();
		
		Product p = new Product();
		
		p.setDelivery(pd.getDelivery());
		p.setDiscount(pd.getDiscount());
		p.setpDesc(pd.getpDesc());
		p.setpName(pd.getpName());
		p.setPrice(pd.getPrice());
		p.setProductId(pd.getProductId());
		p.setRating(pd.getRating());
		p.setSeller(pd.getSeller());
		
		return p;
	}

}
