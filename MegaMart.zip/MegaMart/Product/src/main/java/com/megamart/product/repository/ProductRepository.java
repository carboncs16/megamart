package com.megamart.product.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.megamart.product.document.ProductDocument;

@Transactional
public interface ProductRepository extends MongoRepository<ProductDocument, String> {

}
