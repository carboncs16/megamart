package com.megamart.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.megamart.product.model.Product;
import com.megamart.product.service.ProductService;

@Controller
public class ProductController {
	@Autowired
	ProductService productService;
	
	@RequestMapping(value = "/products", method = RequestMethod.GET, headers="Accept=application/json")
	public ResponseEntity<List<Product>> login() {
		List<Product> productArray = productService.getAllProducts();
		return new ResponseEntity<List<Product>>(productArray, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/product/{productId}", method = RequestMethod.GET, headers="Accept=application/json")
	public ResponseEntity<Product> find(@PathVariable String productId) {
		Product product = productService.getProductById(productId);
		return new ResponseEntity<Product>(product, HttpStatus.OK);
	}
}
