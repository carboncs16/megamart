package com.megamart.wishlist.document;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.megamart.wishlist.model.Wishlist;

@Document(collection="wishlist")
public class WishlistSingleDocument {
	
	@Id
	private String username;
	private Wishlist wishlist;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Wishlist getWishlist() {
		return wishlist;
	}
	public void setWishlist(Wishlist wishlist) {
		this.wishlist = wishlist;
	}
	
}
