package com.megamart.wishlist.model;

import java.util.List;

public class WishlistCollection {

	private String username;
	private List<Wishlist> wishlist;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public List<Wishlist> getWishlist() {
		return wishlist;
	}
	public void setWishlist(List<Wishlist> wishlist) {
		this.wishlist = wishlist;
	}
	
}
