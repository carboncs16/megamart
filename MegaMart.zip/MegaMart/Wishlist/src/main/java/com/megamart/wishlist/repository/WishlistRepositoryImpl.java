package com.megamart.wishlist.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

//import com.megamart.cart.document.CartSingleDocument;
import com.megamart.wishlist.document.WishlistSingleDocument;

@Repository
public class WishlistRepositoryImpl implements CustomWishlistRepository {

	
	@Autowired
	MongoTemplate mongoTemplate;
	@Override
	public String addToWishlist(WishlistSingleDocument wd) {
		// TODO Auto-generated method stub
			
		Query query = new Query(Criteria.where("_id").is(wd.getUsername()));
		Update update = new Update();
		update.push("wishlist", wd.getWishlist());
		
		mongoTemplate.updateFirst(query, update, WishlistSingleDocument.class);
			
		
		return "Update Successful";
	}

}
