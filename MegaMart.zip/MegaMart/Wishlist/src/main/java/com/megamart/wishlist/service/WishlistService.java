package com.megamart.wishlist.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.megamart.wishlist.document.WishlistDocument;
import com.megamart.wishlist.document.WishlistSingleDocument;
import com.megamart.wishlist.model.WishlistCollection;
import com.megamart.wishlist.model.WishlistSingle;
import com.megamart.wishlist.repository.CustomWishlistRepository;
import com.megamart.wishlist.repository.WishlistRepository;

@Service
public class WishlistService {

	@Autowired
	private WishlistRepository wr;
	
	@Autowired
	private CustomWishlistRepository cwr;
	
	public String addToWishlist(WishlistSingle wc) {
		
		WishlistSingleDocument wd = new WishlistSingleDocument();
		
		wd.setUsername(wc.getUsername());
		wd.setWishlist(wc.getWishlist());
		
		String status = cwr.addToWishlist(wd);
		
		return status;
		
	}

	public WishlistCollection getWishlist(String username) {
		// TODO Auto-generated method stub
		Optional<WishlistDocument> wc = wr.findById(username);
		WishlistDocument wd = wc.get();
		WishlistCollection wc1 = new WishlistCollection();
		wc1.setUsername(wd.getUsername());
		wc1.setWishlist(wd.getWishlist());
		
		return wc1;
	}

	public String createWishList(WishlistCollection cart) {
		// TODO Auto-generated method stub
		WishlistDocument wd = new WishlistDocument();
		wd.setUsername(cart.getUsername());
		wd.setWishlist(cart.getWishlist());
		wr.insert(wd);
		
		return "Successfully created";
	}

}
