package com.megamart.wishlist.model;

import com.megamart.wishlist.model.Wishlist;

public class WishlistSingle {
	
	private String username;
	private Wishlist wishlist;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Wishlist getWishlist() {
		return wishlist;
	}
	public void setWishlist(Wishlist wishlist) {
		this.wishlist = wishlist;
	}
	
}
