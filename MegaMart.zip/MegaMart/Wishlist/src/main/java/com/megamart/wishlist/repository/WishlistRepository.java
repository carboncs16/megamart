package com.megamart.wishlist.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.transaction.annotation.Transactional;

import com.megamart.wishlist.document.WishlistDocument;
//import com.megamart.wishlist.model.WishlistCollection;

@Transactional
public interface WishlistRepository extends MongoRepository<WishlistDocument, String> {

}
