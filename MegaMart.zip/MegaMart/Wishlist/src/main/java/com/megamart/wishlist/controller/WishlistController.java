package com.megamart.wishlist.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.megamart.wishlist.model.WishlistCollection;
import com.megamart.wishlist.model.WishlistSingle;
import com.megamart.wishlist.service.WishlistService;

@Controller
public class WishlistController {

	@Autowired
	WishlistService ws;
	@RequestMapping(value = "/create-wishlist", method = RequestMethod.POST, headers="Accept=application/json")
	public ResponseEntity<String> createCart(@RequestBody WishlistCollection cart) {
		String status = ws.createWishList(cart);
		return new ResponseEntity<String>(status, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/add-to-wishlist", method = RequestMethod.POST, headers = "Accept=application/json")
	public ResponseEntity<String> addToWishlist(@RequestBody WishlistSingle wc) {
		
		String res = ws.addToWishlist(wc);
		return new ResponseEntity<String>(res, HttpStatus.OK);
		
	}
	
	@RequestMapping(value = "/get-wishlist/{username}", method = RequestMethod.GET, headers = "Accept=application/json")
	public ResponseEntity<WishlistCollection> getWishlist(@PathVariable String username) {
		WishlistCollection wc = ws.getWishlist(username);
		return new ResponseEntity<WishlistCollection>(wc, HttpStatus.OK);
	}

}
