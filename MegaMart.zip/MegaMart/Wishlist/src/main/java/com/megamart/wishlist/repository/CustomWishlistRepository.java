package com.megamart.wishlist.repository;

import com.megamart.wishlist.document.WishlistSingleDocument;

public interface CustomWishlistRepository {
	
	String addToWishlist(WishlistSingleDocument wd);

}
