package com.megamart.cart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.megamart.cart.model.Cart;
import com.megamart.cart.model.CartCollection;
import com.megamart.cart.model.CartSingle;
import com.megamart.cart.service.CartService;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;


@Controller
public class CartController {

	@Autowired
	CartService cartService;
	@RequestMapping(value = "/create-cart", method = RequestMethod.POST, headers="Accept=application/json")
	public ResponseEntity<String> createCart(@RequestBody CartCollection cart) {
		String status = cartService.createCart(cart);
		return new ResponseEntity<String>(status, HttpStatus.OK);
	}
	@RequestMapping(value = "/add-to-cart", method = RequestMethod.POST, headers="Accept=application/json")
	public ResponseEntity<String> postMethodName(@RequestBody CartSingle cart) {
		//TODO: process POST request
		String status = cartService.addToCart(cart);
		return new ResponseEntity<String>(status, HttpStatus.OK);
	}
	@RequestMapping(value = "/get-cart/{username}", method = RequestMethod.GET, headers="Accept=application/json")
	public ResponseEntity<List<Cart>> getCartDetails(@PathVariable String username) {
		//TODO: process POST request
		List<Cart> cart = cartService.getCart(username);
		return new ResponseEntity<List<Cart>>(cart, HttpStatus.OK);
	}
	@RequestMapping(value = "/empty-cart", method = RequestMethod.POST, headers="Accept=application/json")
	public ResponseEntity<String> emptyCart(@RequestBody CartCollection cart) {
		String status = cartService.emptyCart(cart);
		return new ResponseEntity<String>(status, HttpStatus.OK);
	}
}
