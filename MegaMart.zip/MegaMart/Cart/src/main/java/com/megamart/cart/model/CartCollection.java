package com.megamart.cart.model;

import java.util.List;

public class CartCollection {
	
	private String username;
	private List<Cart> cart;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public List<Cart> getCart() {
		return cart;
	}
	public void setCart(List<Cart> cart) {
		this.cart = cart;
	}
}
