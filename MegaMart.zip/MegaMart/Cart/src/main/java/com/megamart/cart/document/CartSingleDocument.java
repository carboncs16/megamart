package com.megamart.cart.document;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.megamart.cart.model.Cart;

@Document(collection = "cart")
public class CartSingleDocument {

	@Id
	private String username;
	private Cart cart;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Cart getCart() {
		return cart;
	}
	public void setCart(Cart cart) {
		this.cart = cart;
	}
	
}
