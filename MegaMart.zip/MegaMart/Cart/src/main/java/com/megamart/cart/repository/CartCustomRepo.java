package com.megamart.cart.repository;

import com.megamart.cart.document.CartSingleDocument;

public interface CartCustomRepo {
	
	int updateCart(CartSingleDocument cart);
}
