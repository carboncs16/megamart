package com.megamart.cart.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.megamart.cart.document.CartCollectionDocument;
import com.megamart.cart.document.CartSingleDocument;
import com.megamart.cart.model.Cart;
import com.megamart.cart.model.CartCollection;
import com.megamart.cart.model.CartSingle;
import com.megamart.cart.repository.CartCustomRepo;
//import com.megamart.cart.repository.CartRepositoryImpl;
import com.megamart.cart.repository.CartRepository;

@Service
public class CartService {
	
	@Autowired(required=false)
	CartRepository cr;
	
	@Autowired
	CartCustomRepo cartCustomRepo;

	public String addToCart(CartSingle cart) {
		// TODO Auto-generated method stub
		
		
//		CartCollectionDocument cc = new CartCollectionDocument();
		CartSingleDocument cc = new CartSingleDocument();
		cc.setUsername(cart.getUsername());
		cc.setCart(cart.getCart());
		cartCustomRepo.updateCart(cc);
		
		return "Done";
	}

	public List<Cart> getCart(String username) {
		// TODO Auto-generated method stub
		
		Optional<CartCollectionDocument> cart = cr.findById(username);
		
		List<Cart> c = cart.get().getCart();
		
		return c;
	}

	public String createCart(CartCollection cart) {
		// TODO Auto-generated method stub
		CartCollectionDocument cc = new CartCollectionDocument();
		cc.setCart(cart.getCart());
		cc.setUsername(cart.getUsername());
		cr.insert(cc);
		return "Cart created";
	}

	public String emptyCart(CartCollection cart) {
		// TODO Auto-generated method stub
		CartCollectionDocument cc = new CartCollectionDocument();
		cc.setCart(cart.getCart());;
		cc.setUsername(cart.getUsername());;
		cr.save(cc);
		return "Emptied the cart";
	}

}
