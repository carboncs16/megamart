package com.megamart.cart.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
//import org.springframework.data.mongodb.core.query.CriteriaDefinition;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;
//import org.springframework.transaction.annotation.Transactional;

import com.megamart.cart.document.CartSingleDocument;
//import com.mongodb.WriteResult;

@Repository
public class CartRepositoryImpl implements CartCustomRepo {
	
	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public int updateCart(CartSingleDocument cart) {
		
		Query query = new Query(Criteria.where("_id").is(cart.getUsername()));
		Update update = new Update();
		update.push("cart", cart.getCart());
		
		mongoTemplate.updateFirst(query, update, CartSingleDocument.class);
		
		return 0;
	}

}
